package com.garulo.prueba.ciudadesgrandes.model;

import com.fasterxml.jackson.annotation.JsonUnwrapped;

import java.math.BigDecimal;

public record Suggestion(@JsonUnwrapped City city, BigDecimal score) {

}
