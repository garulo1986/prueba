package com.garulo.prueba.ciudadesgrandes.impl.scoring;

import org.springframework.stereotype.Service;

import com.garulo.prueba.ciudadesgrandes.api.ScoringService;
import com.garulo.prueba.ciudadesgrandes.model.City;
import com.garulo.prueba.ciudadesgrandes.model.Query;
import com.garulo.prueba.ciudadesgrandes.model.Suggestion;

import lombok.extern.slf4j.Slf4j;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ScoringServiceImpl implements ScoringService {

	private static final int SCALE = 2;

	private static final BigDecimal MAX_RELEVANT_DISTANCE = BigDecimal.valueOf(40);

	@Override
	public List<Suggestion> evaluate(Query query, List<City> cities) {
		try {
		return cities.stream().map(city -> new Suggestion(city, computeScore(query, city)))
				.collect(Collectors.toList());
		}catch (UnsupportedOperationException e) {
			List<Suggestion> lst = new ArrayList<>();
			return lst;
		}catch (IllegalStateException e) {
			List<Suggestion> lst = new ArrayList<>();
			return lst;
		}
	}

	private BigDecimal computeScore(Query query, City city) {
		var nameScore = computeNameScore(query.getQueryString(), city.getShortName());
		if (query.getLatitude() == null || query.getLongitude() == null) {
			return nameScore;
		}
		var coordinateScore = computeCoordinateScore(query.getLatitude(), query.getLongitude(), city.getLatitude(),
				city.getLongitude());

		return nameScore.add(coordinateScore).divide(BigDecimal.valueOf(2L), 1, RoundingMode.CEILING);
	}

	private BigDecimal computeCoordinateScore(@NotNull BigDecimal requestedLatitude,
			@NotNull BigDecimal requestedLongitude, @NotNull BigDecimal actualLatitude,
			@NotNull BigDecimal actualLongitude) {

		var latitudeDiffSquared = computeDiffSquared(requestedLatitude, actualLatitude);
		var longitudeDiffSquared = computeDiffSquared(requestedLongitude, actualLongitude);
		var distance = latitudeDiffSquared.add(longitudeDiffSquared).sqrt(MathContext.DECIMAL32).setScale(1,
				RoundingMode.CEILING);
		if (distance.compareTo(MAX_RELEVANT_DISTANCE) > 0) {
			return BigDecimal.ZERO;
		}
		return BigDecimal.ZERO.max(BigDecimal.ONE
				.subtract(distance.divide(MAX_RELEVANT_DISTANCE, RoundingMode.FLOOR).sqrt(MathContext.DECIMAL32)));
	}

	private BigDecimal computeDiffSquared(BigDecimal requestedLatitude, BigDecimal actualLatitude) {
		var diff = requestedLatitude.subtract(actualLatitude).abs();
		if (diff.compareTo(BigDecimal.valueOf(180L)) > 0) {
			
			throw new UnsupportedOperationException(
					"Discrepancy in coordinates not yet defined: " + requestedLatitude + " : " + actualLatitude);
		}
		return diff.pow(2);
	}

	private BigDecimal computeNameScore(String queryString, String name) {
		if (!name.startsWith(queryString)) {
			throw new IllegalStateException("Name must start with queryString : Error");
		}
		return BigDecimal.valueOf(queryString.length()).divide(BigDecimal.valueOf(name.length()), SCALE,
				RoundingMode.CEILING);
	}
}
