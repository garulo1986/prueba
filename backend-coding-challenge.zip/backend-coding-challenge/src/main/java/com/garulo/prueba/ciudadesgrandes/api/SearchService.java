package com.garulo.prueba.ciudadesgrandes.api;

import java.util.List;

import com.garulo.prueba.ciudadesgrandes.model.City;

public interface SearchService {

    List<City> search(String queryString);
}
