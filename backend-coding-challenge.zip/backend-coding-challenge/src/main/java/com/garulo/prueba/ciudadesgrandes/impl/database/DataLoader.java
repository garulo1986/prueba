package com.garulo.prueba.ciudadesgrandes.impl.database;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.garulo.prueba.ciudadesgrandes.model.City;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@Slf4j
public class DataLoader {

    private static final int ID_IDX = 0;
    private static final int NAME_IDX = 1;
    private static final int LATITUDE_IDX = 4;
    private static final int LONGITUDE_IDX = 5;
    private static final int COUNTRY_IDX = 8;
    private static final int STATE_IDX = 10;

    public static final String CANADA = "CA";

    public NavigableMap<String, City> loadData(String filepath) throws IOException {
        File file = new File(filepath);
        final Collection<City> cities;
        try (var lines = Files.lines(file.toPath()).skip(1)) {
            cities = lines
                    .map(line -> line.split("\t"))
                    .map(DataLoader::buildUniqueCityName)
                    .collect(Collectors.toList());
        }

        return new TreeMap<>(removeInvalidData(cities).stream().collect(Collectors.toMap(City::getName,
                Function.identity())));
    }

    private Collection<City> removeInvalidData(Collection<City> cities) {
        Map<String, City> uniqueCities = new HashMap<>();
        for (City city : cities) {
            if (city.getName() == null || !StringUtils.hasText(city.getName())) {
                log.info("Empty city name: {}", city);
                continue;
            }

            final City old = uniqueCities.put(city.getName(), city);
            if (old != null) {
                log.info("Duplicate city:  {}", city);
            }
        }
        return uniqueCities.values();
    }

    private static City buildUniqueCityName(String[] input) {
        final long id = Long.parseLong(input[ID_IDX]);
        final String country = input[COUNTRY_IDX];
        final String shortName = input[NAME_IDX];
        final String fullName = shortName + ", " +
                (country.equals(CANADA) ?
                        CanadianProvince.ofFipsCode(Integer.parseInt(input[STATE_IDX])).name() :
                        input[STATE_IDX])
                + ", " + country;
        return City.of(id, shortName, fullName, new BigDecimal(input[LATITUDE_IDX]),
                new BigDecimal(input[LONGITUDE_IDX]));
    }
}
