package com.garulo.prueba.ciudadesgrandes.impl.suggest;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import com.garulo.prueba.ciudadesgrandes.api.ScoringService;
import com.garulo.prueba.ciudadesgrandes.api.SearchService;
import com.garulo.prueba.ciudadesgrandes.api.SuggestionService;
import com.garulo.prueba.ciudadesgrandes.model.Query;
import com.garulo.prueba.ciudadesgrandes.model.Suggestion;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SuggestionServiceImpl implements SuggestionService {

	private final SearchService searchService;

	private final ScoringService scoringService;

	@Override
	public List<Suggestion> getSuggestion(Query query) {
		return scoringService.evaluate(query, searchService.search(query.getQueryString())).stream()
				.sorted(Comparator.comparing(Suggestion::score).reversed()).collect(Collectors.toList());
	}
}
