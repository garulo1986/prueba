package com.garulo.prueba.ciudadesgrandes.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.garulo.prueba.ciudadesgrandes.api.SuggestionService;
import com.garulo.prueba.ciudadesgrandes.model.Query;
import com.garulo.prueba.ciudadesgrandes.model.Suggestion;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class CitySuggestionController {

    private final SuggestionService suggestionService;

    @GetMapping("/suggestions")
    public List<Suggestion> getSuggestion(@RequestParam(name = "q") String query,
                                          @RequestParam(name = "latitude",required = false) BigDecimal latitude,
                                          @RequestParam(name = "longitude",required = false) BigDecimal longitude) {
        return suggestionService.getSuggestion(new Query(query, latitude, longitude));
    }
}
