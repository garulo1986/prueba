package com.garulo.prueba.ciudadesgrandes.api;

import java.util.List;

import com.garulo.prueba.ciudadesgrandes.model.Query;
import com.garulo.prueba.ciudadesgrandes.model.Suggestion;

public interface SuggestionService {

    List<Suggestion> getSuggestion(Query query);
}
