package com.garulo.prueba.ciudadesgrandes.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.garulo.prueba.ciudadesgrandes.impl.database.DataLoader;
import com.garulo.prueba.ciudadesgrandes.model.City;

import java.io.IOException;
import java.util.NavigableMap;

@Configuration
@RequiredArgsConstructor
public class DataConfig {

	private final ConfigProperties configProperties;

	private final DataLoader dataLoader;

	@Bean
	NavigableMap<String, City> loadData() throws IOException {
		return dataLoader.loadData(configProperties.getFilepath());
	}
}
