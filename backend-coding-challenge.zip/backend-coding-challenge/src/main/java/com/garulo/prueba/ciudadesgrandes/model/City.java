package com.garulo.prueba.ciudadesgrandes.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

@Data(staticConstructor = "of")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class City {
	@JsonIgnore
	private final long id;

	@JsonIgnore
	private final String shortName;

	@EqualsAndHashCode.Include
	private final String name;
	private final BigDecimal latitude;
	private final BigDecimal longitude;

	public static City of(long id, String name, BigDecimal latitude, BigDecimal longitude) {
		return of(id, name, name, latitude, longitude);
	}

	public static City of(long id, String name) {
		return of(id, name, null, null);
	}
}
