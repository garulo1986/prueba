package com.garulo.prueba.ciudadesgrandes.model;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class Query {

	private final String queryString;

	private final BigDecimal latitude;

	private final BigDecimal longitude;
}
