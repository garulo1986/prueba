package com.garulo.prueba.ciudadesgrandes.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "garulo")
@Data
public class ConfigProperties {

    private String filepath;
}
