package com.garulo.prueba.ciudadesgrandes.impl.scoring;

import org.junit.jupiter.api.Test;

import com.garulo.prueba.ciudadesgrandes.api.ScoringService;
import com.garulo.prueba.ciudadesgrandes.model.City;
import com.garulo.prueba.ciudadesgrandes.model.Query;
import com.garulo.prueba.ciudadesgrandes.model.Suggestion;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ScoringServiceImplTest {

	private final ScoringService scoringService = new ScoringServiceImpl();

	@Test
	void testNoCities() {

		Query query = new Query("Londo", null, null);

		final List<Suggestion> suggestions = scoringService.evaluate(query, List.of());

		assertNotNull(suggestions);
		assertTrue(suggestions.isEmpty());
	}

	@Test
	void testExactMatchNoCoordinates() {

		Query query = new Query("St. Petersburg", null, null);

		final List<Suggestion> suggestions = scoringService.evaluate(query,
				List.of(City.of(1L, "St. Petersburg", BigDecimal.ONE, BigDecimal.TEN)));

		assertNotNull(suggestions);
		assertEquals(1, suggestions.size());
		final Suggestion suggestion = suggestions.get(0);
		assertEquals(0, BigDecimal.ONE.compareTo(suggestion.score()));
	}

	@Test
	void testExactMatchAntipode() {
		Query query = new Query("St. Petersburg", BigDecimal.valueOf(60), BigDecimal.valueOf(30));

		final List<Suggestion> suggestions = scoringService.evaluate(query,
				List.of(City.of(1L, "St. Petersburg", BigDecimal.valueOf(60 - 180), BigDecimal.valueOf(30 - 180))));

		assertNotNull(suggestions);
		assertEquals(1, suggestions.size());
		final Suggestion suggestion = suggestions.get(0);
		assertEquals(BigDecimal.valueOf(5, 1), suggestion.score());
	}

	@Test
	void testWrongName() {
/*
		Query query = new Query("Londo", null, null);

		assertThrows(IllegalStateException.class, () -> scoringService.evaluate(query,
				List.of(City.of(1L, "St. Petersburg", BigDecimal.ONE, BigDecimal.TEN))));
	*/}

	@Test
	void testPartialMatchNoCoordinates() {

		Query query = new Query("London", null, null);

		final List<Suggestion> suggestions = scoringService.evaluate(query,
				List.of(City.of(1L, "Londonderry", BigDecimal.ONE, BigDecimal.TEN)));

		assertNotNull(suggestions);
		assertEquals(1, suggestions.size());
		final Suggestion suggestion = suggestions.get(0);
		final BigDecimal expected = BigDecimal.valueOf(6).divide(BigDecimal.valueOf(11), 2, RoundingMode.CEILING);
		assertEquals(expected, suggestion.score());
	}

	@Test
	void testExactMatchFullnameDiffer() {

		Query query = new Query("St. Petersburg", null, null);

		final List<Suggestion> suggestions = scoringService.evaluate(query,
				List.of(City.of(1L, "St. Petersburg", "St. Petersburg, Russia", BigDecimal.ONE, BigDecimal.TEN)));

		assertNotNull(suggestions);
		assertEquals(1, suggestions.size());
		final Suggestion suggestion = suggestions.get(0);
		assertEquals(0, BigDecimal.ONE.compareTo(suggestion.score()));
	}

	@Test
	void testExactMatchNeighborhood() {
		Query query = new Query("St. Petersburg", BigDecimal.valueOf(60), BigDecimal.valueOf(30));

		final List<Suggestion> suggestions = scoringService.evaluate(query,
				List.of(City.of(1L, "St. Petersburg", BigDecimal.valueOf(60.03), BigDecimal.valueOf(29.07))));

		assertNotNull(suggestions);
		assertEquals(1, suggestions.size());
		final Suggestion suggestion = suggestions.get(0);
		assertEquals(0, BigDecimal.ONE.compareTo(suggestion.score()));
	}

}