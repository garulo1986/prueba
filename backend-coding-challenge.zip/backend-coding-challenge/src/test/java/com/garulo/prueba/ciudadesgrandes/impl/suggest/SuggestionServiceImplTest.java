package com.garulo.prueba.ciudadesgrandes.impl.suggest;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.garulo.prueba.ciudadesgrandes.api.ScoringService;
import com.garulo.prueba.ciudadesgrandes.api.SearchService;
import com.garulo.prueba.ciudadesgrandes.model.City;
import com.garulo.prueba.ciudadesgrandes.model.Query;
import com.garulo.prueba.ciudadesgrandes.model.Suggestion;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SuggestionServiceImplTest {

    @InjectMocks
    private SuggestionServiceImpl suggestionService;

    @Mock
    private SearchService searchService;

    @Mock
    private ScoringService scoringService;

    @Test
    void bestMatchFirst() {
        Query query = new Query("Brigh", null, null);

        final City brighton = City.of(1L, "Brighton");
        final City bright = City.of(1L, "Bright");
        final City brigham_city = City.of(1L, "Brigham City");
        List<City> cities = List.of(brighton, bright, brigham_city);
        when(searchService.search(query.getQueryString())).thenReturn(cities);

        List<Suggestion> suggestions = List.of(
                new Suggestion(brighton, BigDecimal.ONE),
                new Suggestion(brigham_city, BigDecimal.ZERO),
                new Suggestion(bright, BigDecimal.TEN));
        when(scoringService.evaluate(query, cities)).thenReturn(suggestions);

        suggestions = suggestionService.getSuggestion(query);

        assertEquals(3, suggestions.size());
        assertEquals(BigDecimal.TEN, suggestions.get(0).score());
        assertEquals(BigDecimal.ONE, suggestions.get(1).score());
        assertEquals(BigDecimal.ZERO, suggestions.get(2).score());
    }
}