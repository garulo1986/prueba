package com.garulo.prueba.ciudadesgrandes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitiesApplicationTests {

	@Test
	void contextLoads() {
	}

}
