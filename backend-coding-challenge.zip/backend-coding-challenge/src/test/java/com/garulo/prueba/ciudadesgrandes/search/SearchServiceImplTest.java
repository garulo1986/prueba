package com.garulo.prueba.ciudadesgrandes.search;

import org.junit.jupiter.api.Test;

import com.garulo.prueba.ciudadesgrandes.impl.search.SearchServiceImpl;
import com.garulo.prueba.ciudadesgrandes.model.City;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.NavigableMap;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class SearchServiceImplTest {

	@Test
	void searchExact() {
		SearchServiceImpl searchService = prepareLondons();

		final List<City> cities = searchService.search("London, KY, USA");

		assertNotNull(cities);
		assertEquals(1, cities.size());
		assertEquals(City.of(3L, "London, KY, USA", BigDecimal.valueOf(37.12898d), BigDecimal.valueOf(-84.08326d)),
				cities.get(0));
	}

	@Test
	void searchWildcardSingle() {
		SearchServiceImpl searchService = prepareLondons();

		final List<City> cities = searchService.search("London, ON");

		assertNotNull(cities);
		assertEquals(1, cities.size());
		final Set<String> cityNames = cities.stream().map(City::getName).collect(Collectors.toSet());
		assertEquals(Set.of("London, ON, Canada"), cityNames);
	}

	@Test
	void searchWildcardMultiple() {

		SearchServiceImpl searchService = prepareLondons();

		final List<City> cities = searchService.search("London, O");

		assertNotNull(cities);
		assertEquals(2, cities.size());
		final Set<String> cityNames = cities.stream().map(City::getName).collect(Collectors.toSet());
		assertEquals(Set.of("London, ON, Canada", "London, OH, USA"), cityNames);
	}

	private SearchServiceImpl prepareLondons() {
		NavigableMap<String, City> data = new DataBuilder()
				.add(City.of(1L, "London, ON, Canada", BigDecimal.valueOf(42.98339d), BigDecimal.valueOf(-81.23304d)))
				.add(City.of(2L, "London, OH, USA", BigDecimal.valueOf(39.88645d), BigDecimal.valueOf(-83.44825d)))
				.add(City.of(3L, "London, KY, USA", BigDecimal.valueOf(37.12898d), BigDecimal.valueOf(-84.08326d)))
				.add(City.of(4L, "Londontowne, MD, USA", BigDecimal.valueOf(38.93345d), BigDecimal.valueOf(-76.54941d)))
				.build();

		return new SearchServiceImpl(data);
	}

	private static class DataBuilder {

		private final TreeMap<String, City> data = new TreeMap<>();

		public DataBuilder add(City city) {
			data.put(city.getName(), city);
			return this;
		}

		public NavigableMap<String, City> build() {
			return Collections.unmodifiableNavigableMap(data);
		}
	}
}